#!/system/bin/sh
MODDIR=${0%/*}

# Wait until Android framework signals boot completion
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

# Wait for telephony provider and RIL daemons to settle
sleep 5

# 1. Apply MediaTek IMS & VoWiFi system properties via resetprop
resetprop -n persist.dbg.wfc_avail_ovr 1
resetprop -n persist.radio.wfc_avail_ovr 1
resetprop -n persist.vendor.mtk.wfc.enable 1
resetprop -n persist.vendor.mtk_wfc_support 1
resetprop -n persist.vendor.mtk.wfc_support 1
resetprop -n ro.vendor.mtk_wfc_support 1
resetprop -n persist.vendor.radio.volte_state 1
resetprop -n persist.vendor.radio.wfc_state 1
resetprop -n persist.vendor.vowifi_support 1
resetprop -n persist.vendor.ims_support 1
resetprop -n persist.vendor.mims_support 2
resetprop -n persist.vendor.dynamic.ims.switch 0

# 2. Inject persistent CarrierConfig parameters for both SIM slots
for slot in 0 1; do
    cmd phone cc set-value -s $slot -p carrier_wfc_ims_available_bool true 2>/dev/null
    cmd phone cc set-value -s $slot -p carrier_wfc_supports_wifi_only_bool true 2>/dev/null
    cmd phone cc set-value -s $slot -p carrier_default_wfc_ims_enabled_bool true 2>/dev/null
    cmd phone cc set-value -s $slot -p carrier_volte_available_bool true 2>/dev/null
    cmd phone cc set-value -s $slot -p carrier_volte_provisioned_bool true 2>/dev/null
    cmd phone cc set-value -s $slot -p imsserviceentitlement.skip_wfc_activation_bool true 2>/dev/null
    cmd phone cc set-value -s $slot -p editable_wfc_mode_bool true 2>/dev/null
done

# 3. Ensure Android Global Settings enable VoWiFi
settings put global wfc_ims_enabled 1 2>/dev/null
settings put global wfc_ims_mode 2 2>/dev/null

# 4. Notify MediaTek RIL / IMS Config service
setprop vendor.ril.imsconfig.force.notify 1

# 5. Execute MtkImsProbe to register WFC resource capability with MTK IMS
if [ -f /system_ext/etc/mtkimsprobe.dex ]; then
    CLASSPATH=/system_ext/etc/mtkimsprobe.dex app_process /system/bin MtkImsProbe enable-cache
elif [ -f "$MODDIR/system/system_ext/etc/mtkimsprobe.dex" ]; then
    CLASSPATH="$MODDIR/system/system_ext/etc/mtkimsprobe.dex" app_process /system/bin MtkImsProbe enable-cache
fi

# 6. Ensure vendor.epdg_wod is running
if [ "$(getprop init.svc.vendor.epdg_wod)" != "running" ]; do
    start vendor.epdg_wod 2>/dev/null
fi
